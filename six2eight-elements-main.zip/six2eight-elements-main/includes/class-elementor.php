<?php
/**
 * Elementor integration.
 *
 * @package Six2eight_Elements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class S2E_Elements_Elementor
 */
class S2E_Elements_Elementor {

	/**
	 * Category slug.
	 */
	const CATEGORY_SLUG = 'six2eight-elements';

	/**
	 * Singleton.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Whether Elementor integration hooks were wired.
	 *
	 * @var bool
	 */
	private static $hooks_wired = false;

	/**
	 * Whether widgets were registered (guard against double registration).
	 *
	 * @var bool
	 */
	private static $widgets_registered = false;

	/**
	 * Whether the custom category was added.
	 *
	 * @var bool
	 */
	private static $category_registered = false;

	/**
	 * Instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Attach Elementor hooks. Safe if Elementor init/widget hooks already ran.
	 */
	public static function register_hooks() {
		if ( self::$hooks_wired ) {
			return;
		}
		self::$hooks_wired = true;

		$self = self::instance();

		if ( did_action( 'elementor/init' ) ) {
			$self->category();
		} else {
			add_action( 'elementor/init', array( $self, 'category' ), 5 );
		}

		if ( did_action( 'elementor/widgets/register' ) ) {
			$self->widgets( \Elementor\Plugin::instance()->widgets_manager );
		} else {
			add_action( 'elementor/widgets/register', array( $self, 'widgets' ) );
		}
	}

	/**
	 * Constructor (kept private; use instance()).
	 */
	private function __construct() {}

	/**
	 * Register custom Elementor category.
	 */
	public function category() {
		if ( self::$category_registered ) {
			return;
		}

		\Elementor\Plugin::instance()->elements_manager->add_category(
			self::CATEGORY_SLUG,
			array(
				'title' => esc_html__( 'Six2eight Elements', 'six2eight-elements' ),
				'icon'  => 'eicon-plug',
			)
		);

		self::$category_registered = true;
	}

	/**
	 * Register widgets.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Widgets manager.
	 */
	public function widgets( $widgets_manager ) {
		if ( self::$widgets_registered ) {
			return;
		}

		require_once S2E_ELEMENTS_PATH . 'widgets/class-s2e-project-steps.php';
		require_once S2E_ELEMENTS_PATH . 'widgets/class-s2e-transformation-slider.php';

		$widgets_manager->register( new S2E_Project_Steps() );
		$widgets_manager->register( new S2E_Transformation_Slider() );

		self::$widgets_registered = true;
	}
}
