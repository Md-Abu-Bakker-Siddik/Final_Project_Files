<?php
/**
 * Gutenberg block registration.
 *
 * @package Six2eight_Elements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class S2E_Elements_Blocks
 */
class S2E_Elements_Blocks {

	/**
	 * Singleton.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'register_blocks' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ) );
		add_filter( 'render_block', array( $this, 'enqueue_frontend_for_block' ), 10, 2 );
	}

	/**
	 * Register native blocks from block.json.
	 */
	public function register_blocks() {
		$project = S2E_ELEMENTS_PATH . 'blocks/project-steps';
		if ( file_exists( $project . '/block.json' ) ) {
			register_block_type( $project );
		}

		$transform = S2E_ELEMENTS_PATH . 'blocks/transformation-slider';
		if ( file_exists( $transform . '/block.json' ) ) {
			register_block_type( $transform );
		}
	}

	/**
	 * Block editor: shared CSS/JS so previews match the site.
	 */
	public function enqueue_editor_assets() {
		S2E_Elements_Assets::instance()->register_shared();
		wp_enqueue_style( S2E_Elements_Assets::STYLE_HANDLE );
		wp_enqueue_script( S2E_Elements_Assets::SCRIPT_HANDLE );
	}

	/**
	 * Frontend: load shared assets only when a Six2eight block is rendered.
	 *
	 * @param string $content Block content.
	 * @param array  $block   Parsed block.
	 * @return string
	 */
	public function enqueue_frontend_for_block( $content, $block ) {
		if ( empty( $block['blockName'] ) || 0 !== strpos( $block['blockName'], 'six2eight/' ) ) {
			return $content;
		}

		S2E_Elements_Assets::instance()->register_shared();
		wp_enqueue_style( S2E_Elements_Assets::STYLE_HANDLE );

		if ( 'six2eight/transformation-slider' === $block['blockName'] ) {
			wp_enqueue_script( S2E_Elements_Assets::SCRIPT_HANDLE );
		}

		return $content;
	}
}
