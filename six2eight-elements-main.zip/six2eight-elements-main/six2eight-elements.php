<?php
/**
 * Plugin Name: Six2eight Elements
 * Description: Project Steps timeline and Transformation Slider for Elementor and Gutenberg.
 * Version: 1.0.0
 * Author: Six2eight
 * Text Domain: six2eight-elements
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package Six2eight_Elements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'S2E_ELEMENTS_VERSION', '1.0.0' );
define( 'S2E_ELEMENTS_PATH', plugin_dir_path( __FILE__ ) );
define( 'S2E_ELEMENTS_URL', plugin_dir_url( __FILE__ ) );

require_once S2E_ELEMENTS_PATH . 'includes/class-assets.php';
require_once S2E_ELEMENTS_PATH . 'includes/class-blocks.php';
require_once S2E_ELEMENTS_PATH . 'includes/class-elementor.php';

/**
 * Bootstrap plugin.
 */
function s2e_elements_bootstrap() {
	S2E_Elements_Assets::instance();
	S2E_Elements_Blocks::instance();

	// Always register; if Elementor is inactive the hook never runs.
	add_action(
		'elementor/loaded',
		static function () {
			if ( class_exists( '\Elementor\Plugin' ) ) {
				S2E_Elements_Elementor::register_hooks();
			}
		},
		5
	);

	// If Elementor loaded before this plugin (unusual), attach immediately.
	if ( did_action( 'elementor/loaded' ) && class_exists( '\Elementor\Plugin' ) ) {
		S2E_Elements_Elementor::register_hooks();
	}
}
add_action( 'plugins_loaded', 's2e_elements_bootstrap' );
